// Thanatos cinematic intro v2 — pure void → reveal → dissolve into home.
// Exposes window.ThanatosIntro.

(function () {
  const { useState, useEffect, useRef, useMemo } = React;

  // ── helpers ───────────────────────────────────────────────
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smoothstep = (e0, e1, x) => {
    const t = clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  };
  const ease = {
    outCubic: (t) => 1 - Math.pow(1 - t, 3),
    inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    outQuart: (t) => 1 - Math.pow(1 - t, 4),
    outExpo: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    inCubic: (t) => t * t * t,
    inExpo: (t) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10)),
  };

  // ── palette ───────────────────────────────────────────────
  const GOLD = '#f5c66b';
  const GOLD_BRIGHT = '#ffd98a';
  const GOLD_DEEP = '#b88030';
  const VOID = '#000000';

  // ── dimensions ────────────────────────────────────────────
  const W = 1920;
  const H = 1080;
  const CENTER_X = W / 2;
  const LOGO_Y_INTRO = 460; // logo center in intro
  const LOGO_Y_HOME = 56;   // top-left header position (y of logo top)
  const LOGO_X_HOME = 56;

  // ── timing ────────────────────────────────────────────────
  const INTRO_DURATION = 12.5;
  const TRANSITION_START = 10.5;
  const TRANSITION_END = 12.0;

  const STORAGE_KEY = 'thanatos_intro_v2_seen';

  // ── Audio engine ─────────────────────────────────────────
  // Synthesizes all sounds via Web Audio API — no external assets.
  class AudioEngine {
    constructor() {
      this.ctx = null;
      this.master = null;
      this.muted = false;
      this.drone = null;
      this.ambient = null;
    }
    init() {
      if (this.ctx) return true;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.85;
        this.master.connect(this.ctx.destination);
        return true;
      } catch (e) {
        return false;
      }
    }
    async resume() {
      if (!this.init()) return false;
      try {
        if (this.ctx.state !== 'running') await this.ctx.resume();
        return this.ctx.state === 'running';
      } catch (e) {
        return false;
      }
    }
    setMuted(m) {
      this.muted = m;
      if (this.master) {
        this.master.gain.cancelScheduledValues(this.ctx.currentTime);
        this.master.gain.linearRampToValueAtTime(m ? 0 : 0.85, this.ctx.currentTime + 0.08);
      }
    }
    // helpers
    now() { return this.ctx.currentTime; }
    env(node, t0, attack, peak, decay, sustain = 0, release = 0) {
      const g = node.gain;
      g.cancelScheduledValues(t0);
      g.setValueAtTime(0.0001, t0);
      g.exponentialRampToValueAtTime(Math.max(peak, 0.0001), t0 + attack);
      g.exponentialRampToValueAtTime(Math.max(sustain || 0.0001, 0.0001), t0 + attack + decay);
      if (release > 0) g.exponentialRampToValueAtTime(0.0001, t0 + attack + decay + release);
    }
    // ── cues ─────────────────────────────────────────────
    startDrone() {
      if (!this.ctx || this.drone) return;
      const t0 = this.now();
      const out = this.ctx.createGain();
      out.gain.value = 0.0001;
      out.gain.exponentialRampToValueAtTime(0.22, t0 + 2.5);
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 320;
      lp.Q.value = 0.7;
      out.connect(lp);
      lp.connect(this.master);
      // sub
      const sub = this.ctx.createOscillator();
      sub.type = 'sine';
      sub.frequency.value = 55;
      const subG = this.ctx.createGain();
      subG.gain.value = 1.0;
      sub.connect(subG); subG.connect(out);
      // bass
      const bass = this.ctx.createOscillator();
      bass.type = 'sine';
      bass.frequency.value = 110;
      const bassG = this.ctx.createGain();
      bassG.gain.value = 0.4;
      // slow LFO on bass
      const lfo = this.ctx.createOscillator();
      lfo.frequency.value = 0.18;
      const lfoG = this.ctx.createGain();
      lfoG.gain.value = 4;
      lfo.connect(lfoG); lfoG.connect(bass.frequency);
      bass.connect(bassG); bassG.connect(out);
      // breath (very slow noise mod)
      const noiseG = this.ctx.createGain();
      noiseG.gain.value = 0.05;
      const noise = this.makeNoise(2);
      const noiseLp = this.ctx.createBiquadFilter();
      noiseLp.type = 'lowpass';
      noiseLp.frequency.value = 120;
      noise.connect(noiseLp); noiseLp.connect(noiseG); noiseG.connect(out);

      sub.start(t0);
      bass.start(t0);
      lfo.start(t0);
      noise.start(t0);
      this.drone = { out, sub, bass, lfo, noise };
    }
    stopDrone(fade = 1.2) {
      if (!this.drone) return;
      const t0 = this.now();
      const d = this.drone;
      d.out.gain.cancelScheduledValues(t0);
      d.out.gain.setValueAtTime(d.out.gain.value, t0);
      d.out.gain.exponentialRampToValueAtTime(0.0001, t0 + fade);
      d.sub.stop(t0 + fade + 0.1);
      d.bass.stop(t0 + fade + 0.1);
      d.lfo.stop(t0 + fade + 0.1);
      d.noise.stop(t0 + fade + 0.1);
      this.drone = null;
    }
    makeNoise(seconds = 2) {
      const sr = this.ctx.sampleRate;
      const buf = this.ctx.createBuffer(1, sr * seconds, sr);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      return src;
    }
    shimmer() {
      if (!this.ctx) return;
      const t0 = this.now();
      const out = this.ctx.createGain();
      this.env(out, t0, 0.4, 0.18, 0.6, 0.08, 0.8);
      out.connect(this.master);
      [1200, 1800, 2700, 3600].forEach((f, i) => {
        const o = this.ctx.createOscillator();
        o.type = 'sine';
        o.frequency.setValueAtTime(f * 0.95, t0);
        o.frequency.exponentialRampToValueAtTime(f * 1.05, t0 + 1.4);
        const g = this.ctx.createGain();
        g.gain.value = 0.18 / (i + 1);
        o.connect(g); g.connect(out);
        o.start(t0); o.stop(t0 + 1.9);
      });
    }
    whoosh() {
      if (!this.ctx) return;
      const t0 = this.now();
      const noise = this.makeNoise(2);
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.value = 1.2;
      bp.frequency.setValueAtTime(200, t0);
      bp.frequency.exponentialRampToValueAtTime(4000, t0 + 1.4);
      const out = this.ctx.createGain();
      this.env(out, t0, 0.15, 0.32, 0.6, 0.08, 0.7);
      noise.connect(bp); bp.connect(out); out.connect(this.master);
      noise.start(t0); noise.stop(t0 + 1.6);
    }
    chime() {
      if (!this.ctx) return;
      const t0 = this.now();
      const partials = [
        { f: 880,  g: 0.35 },
        { f: 1320, g: 0.22 },
        { f: 1760, g: 0.10 },
        { f: 2640, g: 0.05 },
      ];
      partials.forEach((p) => {
        const o = this.ctx.createOscillator();
        o.type = 'sine';
        o.frequency.value = p.f;
        const g = this.ctx.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(p.g, t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 3.2);
        o.connect(g); g.connect(this.master);
        o.start(t0); o.stop(t0 + 3.3);
      });
      // sub thump under the chime
      const sub = this.ctx.createOscillator();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(110, t0);
      sub.frequency.exponentialRampToValueAtTime(55, t0 + 0.4);
      const subG = this.ctx.createGain();
      subG.gain.setValueAtTime(0.0001, t0);
      subG.gain.exponentialRampToValueAtTime(0.45, t0 + 0.02);
      subG.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.2);
      sub.connect(subG); subG.connect(this.master);
      sub.start(t0); sub.stop(t0 + 1.3);
    }
    tick(idx = 0) {
      if (!this.ctx) return;
      const t0 = this.now();
      const base = 1500 + idx * 70;
      [base, base * 2].forEach((f, i) => {
        const o = this.ctx.createOscillator();
        o.type = 'sine';
        o.frequency.value = f;
        const g = this.ctx.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(0.16 / (i + 1), t0 + 0.005);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.18);
        o.connect(g); g.connect(this.master);
        o.start(t0); o.stop(t0 + 0.2);
      });
      // little noise click
      const n = this.makeNoise(0.1);
      const hp = this.ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 2000;
      const ng = this.ctx.createGain();
      ng.gain.setValueAtTime(0.0001, t0);
      ng.gain.exponentialRampToValueAtTime(0.08, t0 + 0.002);
      ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.06);
      n.connect(hp); hp.connect(ng); ng.connect(this.master);
      n.start(t0); n.stop(t0 + 0.1);
    }
    bassImpact() {
      if (!this.ctx) return;
      const t0 = this.now();
      // 60Hz sine with sharp envelope
      const o = this.ctx.createOscillator();
      o.type = 'sine';
      o.frequency.setValueAtTime(120, t0);
      o.frequency.exponentialRampToValueAtTime(45, t0 + 0.25);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.7, t0 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.4);
      o.connect(g); g.connect(this.master);
      o.start(t0); o.stop(t0 + 1.5);
      // noise burst on top
      const n = this.makeNoise(0.3);
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 600;
      const ng = this.ctx.createGain();
      ng.gain.setValueAtTime(0.0001, t0);
      ng.gain.exponentialRampToValueAtTime(0.28, t0 + 0.01);
      ng.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.6);
      n.connect(lp); lp.connect(ng); ng.connect(this.master);
      n.start(t0); n.stop(t0 + 0.65);
    }
    highSweep() {
      if (!this.ctx) return;
      const t0 = this.now();
      const n = this.makeNoise(1.5);
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass'; bp.Q.value = 2.2;
      bp.frequency.setValueAtTime(1500, t0);
      bp.frequency.exponentialRampToValueAtTime(5500, t0 + 0.9);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.18, t0 + 0.18);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.0);
      n.connect(bp); bp.connect(g); g.connect(this.master);
      n.start(t0); n.stop(t0 + 1.05);
    }
    transitionWhoosh() {
      if (!this.ctx) return;
      const t0 = this.now();
      // descending noise sweep
      const n = this.makeNoise(2);
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass'; bp.Q.value = 1.5;
      bp.frequency.setValueAtTime(3500, t0);
      bp.frequency.exponentialRampToValueAtTime(220, t0 + 1.5);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.32, t0 + 0.2);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.6);
      n.connect(bp); bp.connect(g); g.connect(this.master);
      n.start(t0); n.stop(t0 + 1.7);
      // descending tone
      const o = this.ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(440, t0);
      o.frequency.exponentialRampToValueAtTime(80, t0 + 1.4);
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 800;
      const og = this.ctx.createGain();
      og.gain.setValueAtTime(0.0001, t0);
      og.gain.exponentialRampToValueAtTime(0.12, t0 + 0.15);
      og.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.5);
      o.connect(lp); lp.connect(og); og.connect(this.master);
      o.start(t0); o.stop(t0 + 1.6);
    }
    settle() {
      if (!this.ctx) return;
      const t0 = this.now();
      // soft sustained perfect fifth, low gain, fades into home ambient
      const out = this.ctx.createGain();
      out.gain.setValueAtTime(0.0001, t0);
      out.gain.exponentialRampToValueAtTime(0.14, t0 + 0.6);
      out.gain.exponentialRampToValueAtTime(0.04, t0 + 3.5);
      out.gain.exponentialRampToValueAtTime(0.0001, t0 + 7.0);
      out.connect(this.master);
      [220, 330, 440].forEach((f, i) => {
        const o = this.ctx.createOscillator();
        o.type = i === 0 ? 'sine' : 'triangle';
        o.frequency.value = f;
        const g = this.ctx.createGain();
        g.gain.value = 0.4 / (i + 1);
        o.connect(g); g.connect(out);
        o.start(t0); o.stop(t0 + 7.1);
      });
    }
  }

  // Cue list — fired when intro time crosses each threshold
  const CUES = [
    { t: 0.0,  name: 'drone' },
    { t: 1.6,  name: 'shimmer' },
    { t: 2.4,  name: 'whoosh' },
    { t: 3.5,  name: 'chime' },
    { t: 4.80, name: 'tick', idx: 0 },
    { t: 4.93, name: 'tick', idx: 1 },
    { t: 5.06, name: 'tick', idx: 2 },
    { t: 5.19, name: 'tick', idx: 3 },
    { t: 5.32, name: 'tick', idx: 4 },
    { t: 5.45, name: 'tick', idx: 5 },
    { t: 5.58, name: 'tick', idx: 6 },
    { t: 5.71, name: 'tick', idx: 7 },
    { t: 6.10, name: 'bass' },
    { t: 7.40, name: 'highsweep' },
    { t: 10.50, name: 'transitionwhoosh' },
    { t: 10.55, name: 'stopdrone' },
    { t: 12.00, name: 'settle' },
  ];

  // ── stable particle field ─────────────────────────────────
  function buildParticles(seed, count) {
    let s = seed;
    const rand = () => {
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };
    const arr = [];
    for (let i = 0; i < count; i++) {
      arr.push({
        angle: rand() * Math.PI * 2,
        startDist: rand() * 80,
        speed: 0.18 + rand() * 0.4,
        phase: rand() * 4,
        size: 1 + rand() * 2.5,
        twinkle: 0.6 + rand() * 1.6,
      });
    }
    return arr;
  }

  function buildAmbient(seed, count) {
    let s = seed;
    const rand = () => {
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };
    const arr = [];
    for (let i = 0; i < count; i++) {
      arr.push({
        x: rand() * W,
        y: rand() * H,
        size: 0.6 + rand() * 1.8,
        phase: rand() * Math.PI * 2,
        twinkle: 0.4 + rand() * 1.0,
        drift: (rand() - 0.5) * 8,
      });
    }
    return arr;
  }

  // ── streaming particles (hyperspace from center outward) ──
  function StreamingParticles({ time, push }) {
    const particles = useMemo(() => buildParticles(2027, 140), []);
    const reveal = smoothstep(0.6, 3.0, time);
    const fadeOut = 1 - smoothstep(TRANSITION_START, TRANSITION_END, time);
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {particles.map((p, i) => {
          // each particle cycles: dist grows from 0 to ~1100 over a period, then resets
          const cycle = 3.5;
          const phaseT = ((time * p.speed + p.phase) % cycle) / cycle;
          const distNorm = phaseT; // 0..1
          const dist = p.startDist + distNorm * 1100;
          const x = CENTER_X + Math.cos(p.angle) * dist;
          const y = LOGO_Y_INTRO + Math.sin(p.angle) * dist * 0.62; // squash vertically
          const sz = p.size * (0.25 + distNorm * 2.2);
          // fade in early, hold, fade out at edge
          const dFade = distNorm < 0.08
            ? distNorm * 12
            : distNorm > 0.85
            ? (1 - distNorm) * 6.6
            : 1;
          const op = reveal * fadeOut * dFade * 0.85;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: x - sz / 2,
                top: y - sz / 2,
                width: sz,
                height: sz,
                borderRadius: '50%',
                background: GOLD_BRIGHT,
                boxShadow: `0 0 ${sz * 4}px ${sz * 0.5}px rgba(245,198,107,0.55)`,
                opacity: op,
                willChange: 'transform, opacity',
              }}
            />
          );
        })}
      </div>
    );
  }

  // ── ambient stars (faint, slow) — alive in home mode too ──
  function AmbientStars({ time, intensity = 1 }) {
    const stars = useMemo(() => buildAmbient(8181, 50), []);
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {stars.map((p, i) => {
          const twk = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(time * p.twinkle + p.phase));
          const x = p.x + Math.sin(time * 0.25 + p.phase) * p.drift;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: x,
                top: p.y,
                width: p.size,
                height: p.size,
                borderRadius: '50%',
                background: GOLD,
                boxShadow: `0 0 ${p.size * 3}px rgba(245,198,107,0.5)`,
                opacity: twk * 0.55 * intensity,
              }}
            />
          );
        })}
      </div>
    );
  }

  // ── volumetric beam shifting angle ───────────────────────
  function Beam({ time }) {
    const a = smoothstep(2.0, 4.0, time);
    const b = 1 - smoothstep(TRANSITION_START, TRANSITION_END, time);
    const sway = Math.sin(time * 0.5) * 8; // degrees
    const pulse = 0.7 + 0.3 * Math.sin(time * 1.4);
    return (
      <div
        style={{
          position: 'absolute',
          left: CENTER_X - 260,
          top: -80,
          width: 520,
          height: H + 160,
          background:
            'radial-gradient(ellipse 260px 620px at 50% 45%, rgba(245,198,107,0.22), rgba(245,198,107,0) 70%)',
          opacity: a * b * pulse,
          transform: `rotate(${sway}deg)`,
          transformOrigin: '50% 0%',
          mixBlendMode: 'screen',
          pointerEvents: 'none',
          filter: 'blur(2px)',
        }}
      />
    );
  }

  // ── core radial glow ─────────────────────────────────────
  function CoreGlow({ time }) {
    // gentle nascent point of light from start
    const seed = smoothstep(0.4, 1.6, time) * 0.5;
    const main = smoothstep(2.5, 5.0, time);
    const exit = 1 - smoothstep(TRANSITION_START, TRANSITION_END, time);
    const breath = 1 + 0.06 * Math.sin(time * 1.3);
    return (
      <div
        style={{
          position: 'absolute',
          left: CENTER_X - 560,
          top: LOGO_Y_INTRO - 560,
          width: 1120,
          height: 1120,
          background:
            'radial-gradient(circle at 50% 50%, rgba(245,198,107,0.55) 0%, rgba(245,198,107,0.22) 20%, rgba(245,198,107,0.05) 42%, rgba(245,198,107,0) 62%)',
          opacity: (seed + main) * exit,
          transform: `scale(${breath})`,
          transformOrigin: 'center',
          mixBlendMode: 'screen',
          pointerEvents: 'none',
          filter: 'blur(10px)',
        }}
      />
    );
  }

  // ── rotating concentric rings ────────────────────────────
  function Rings({ time }) {
    const r1Progress = ease.outQuart(smoothstep(1.6, 3.6, time));
    const r2Progress = ease.outQuart(smoothstep(2.2, 4.2, time));
    const r3Progress = smoothstep(3.0, 5.0, time);
    const ticksProgress = smoothstep(3.6, 5.5, time);
    const exit = 1 - smoothstep(TRANSITION_START, TRANSITION_END, time);

    const outerR = 380;
    const innerR = 310;
    const farR = 460;
    const circOuter = 2 * Math.PI * outerR;
    const circInner = 2 * Math.PI * innerR;
    const circFar = 2 * Math.PI * farR;

    const sweepAngle = (time * 110) % 360; // continuous orbit

    return (
      <svg
        width={W}
        height={H}
        viewBox={`0 0 ${W} ${H}`}
        style={{
          position: 'absolute',
          inset: 0,
          pointerEvents: 'none',
          opacity: exit,
        }}
      >
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={GOLD} stopOpacity="0" />
            <stop offset="35%" stopColor={GOLD_BRIGHT} stopOpacity="1" />
            <stop offset="70%" stopColor={GOLD_DEEP} stopOpacity="1" />
            <stop offset="100%" stopColor={GOLD} stopOpacity="0" />
          </linearGradient>
          <radialGradient id="sweepGrad">
            <stop offset="0%" stopColor={GOLD_BRIGHT} stopOpacity="1" />
            <stop offset="100%" stopColor={GOLD} stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Far faint ring — slow counter-rotation */}
        <circle
          cx={CENTER_X}
          cy={LOGO_Y_INTRO}
          r={farR}
          fill="none"
          stroke="rgba(245,198,107,0.18)"
          strokeWidth="0.8"
          strokeDasharray="1 6"
          strokeDashoffset={circFar * (1 - r3Progress)}
          transform={`rotate(${-time * 8} ${CENTER_X} ${LOGO_Y_INTRO})`}
        />

        {/* Outer solid ring — draws clockwise */}
        <circle
          cx={CENTER_X}
          cy={LOGO_Y_INTRO}
          r={outerR}
          fill="none"
          stroke="url(#ringGrad)"
          strokeWidth="1.4"
          strokeDasharray={circOuter}
          strokeDashoffset={circOuter * (1 - r1Progress)}
          transform={`rotate(${-90 + time * 5} ${CENTER_X} ${LOGO_Y_INTRO})`}
        />

        {/* Inner dashed ring — counter rotate */}
        <circle
          cx={CENTER_X}
          cy={LOGO_Y_INTRO}
          r={innerR}
          fill="none"
          stroke="rgba(245,198,107,0.55)"
          strokeWidth="1"
          strokeDasharray="2 10"
          strokeDashoffset={circInner * (1 - r2Progress)}
          transform={`rotate(${-time * 18} ${CENTER_X} ${LOGO_Y_INTRO})`}
        />

        {/* Cardinal tick marks */}
        {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => {
          const rad = (deg * Math.PI) / 180;
          const x1 = CENTER_X + Math.cos(rad) * (outerR - 10);
          const y1 = LOGO_Y_INTRO + Math.sin(rad) * (outerR - 10);
          const x2 = CENTER_X + Math.cos(rad) * (outerR + 12);
          const y2 = LOGO_Y_INTRO + Math.sin(rad) * (outerR + 12);
          const major = deg % 90 === 0;
          return (
            <line
              key={deg}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={GOLD}
              strokeWidth={major ? 1.5 : 0.8}
              opacity={ticksProgress * (major ? 0.85 : 0.4)}
            />
          );
        })}

        {/* Orbiting sweep dot */}
        <g
          transform={`rotate(${sweepAngle} ${CENTER_X} ${LOGO_Y_INTRO})`}
          opacity={smoothstep(3.8, 4.6, time) * exit}
        >
          <circle cx={CENTER_X + outerR} cy={LOGO_Y_INTRO} r="14" fill="url(#sweepGrad)" />
          <circle cx={CENTER_X + outerR} cy={LOGO_Y_INTRO} r="3.5" fill={GOLD_BRIGHT} />
        </g>

        {/* Second sweep dot opposite — adds motion */}
        <g
          transform={`rotate(${-sweepAngle * 0.7 + 180} ${CENTER_X} ${LOGO_Y_INTRO})`}
          opacity={smoothstep(4.2, 5.0, time) * exit * 0.7}
        >
          <circle cx={CENTER_X + innerR} cy={LOGO_Y_INTRO} r="9" fill="url(#sweepGrad)" />
          <circle cx={CENTER_X + innerR} cy={LOGO_Y_INTRO} r="2" fill={GOLD_BRIGHT} />
        </g>
      </svg>
    );
  }

  // ── scan-line sweep ──────────────────────────────────────
  function ScanSweep({ time }) {
    const start = 2.4;
    const dur = 1.4;
    const p = smoothstep(start, start + dur, time);
    const active = time > start && time < start + dur + 0.3;
    if (!active) return null;
    const y = lerp(-60, H + 60, p);
    const opacity = (1 - Math.abs(p * 2 - 1)) * 0.55;
    return (
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: y,
          width: '100%',
          height: 160,
          background:
            'linear-gradient(180deg, rgba(245,198,107,0) 0%, rgba(245,198,107,0.22) 50%, rgba(245,198,107,0) 100%)',
          opacity,
          pointerEvents: 'none',
          mixBlendMode: 'screen',
        }}
      />
    );
  }

  // ── logo (morphs from intro center to home top-left) ─────
  function Logo({ time, logo, mode }) {
    // Intro entry
    const introIn = smoothstep(2.8, 4.8, time);
    const breath = 1 + 0.012 * Math.sin(time * 1.2);

    let cx, cy, size, opacity, rot, glow;

    if (mode === 'home') {
      cx = LOGO_X_HOME + 28;
      cy = LOGO_Y_HOME + 28;
      size = 56;
      opacity = 1;
      rot = 0;
      glow = 0.4;
    } else {
      // intro mode
      const trans = ease.inOutCubic(smoothstep(TRANSITION_START, TRANSITION_END, time));
      const introCx = CENTER_X;
      const introCy = LOGO_Y_INTRO;
      const introSize = 420;

      // home target (center of small home logo)
      const homeCx = LOGO_X_HOME + 28;
      const homeCy = LOGO_Y_HOME + 28;
      const homeSize = 56;

      cx = lerp(introCx, homeCx, trans);
      cy = lerp(introCy, homeCy, trans);
      size = lerp(introSize, homeSize, trans);
      opacity = introIn;
      // entry rotation: from -20deg to 0
      rot = lerp(-18, 0, ease.outCubic(introIn));
      // entry scale punch
      const entryScale = lerp(0.6, 1.0, ease.outCubic(introIn));
      size = size * entryScale;
      glow = lerp(1, 0.4, trans);
    }

    return (
      <div
        style={{
          position: 'absolute',
          left: cx - size / 2,
          top: cy - size / 2,
          width: size,
          height: size,
          opacity,
          transform: `scale(${breath}) rotate(${rot}deg)`,
          transformOrigin: 'center',
          filter: `drop-shadow(0 0 ${24 * glow}px rgba(245,198,107,${0.6 * glow})) drop-shadow(0 0 ${64 * glow}px rgba(245,198,107,${0.3 * glow}))`,
          willChange: 'transform, opacity, left, top, width, height',
        }}
      >
        <img
          src={logo}
          alt="Thanatos"
          style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }}
        />
      </div>
    );
  }

  // ── monumental wordmark ──────────────────────────────────
  // Letters slide in from outside the frame and converge into the title.
  function Wordmark({ time }) {
    const letters = ['T', 'H', 'A', 'N', 'A', 'T', 'O', 'S'];
    const baseStart = 4.8;
    const stagger = 0.13;
    const fadeOutGroup = 1 - smoothstep(TRANSITION_START, TRANSITION_END - 0.3, time);

    const SIZE = 260; // monumental
    const LETTER_W = SIZE * 0.62; // ~ width per letter (approx)
    const totalW = LETTER_W * letters.length;
    const startX = CENTER_X - totalW / 2;
    const baselineY = 770;

    return (
      <div
        style={{
          position: 'absolute',
          inset: 0,
          pointerEvents: 'none',
          opacity: fadeOutGroup,
        }}
      >
        {letters.map((ch, i) => {
          const tStart = baseStart + i * stagger;
          const tEnd = tStart + 1.0;
          const p = ease.outQuart(smoothstep(tStart, tEnd, time));
          const visible = time > tStart - 0.1;
          if (!visible) return null;
          // alternate letters come from above/below for vertical motion
          const fromAbove = i % 2 === 0;
          const startY = baselineY + (fromAbove ? -260 : 260);
          const x = startX + i * LETTER_W;
          const y = lerp(startY, baselineY, p);
          // horizontal jitter from start position (parallax drift)
          const jitterStart = (i - letters.length / 2 + 0.5) * 28;
          const xJit = lerp(jitterStart, 0, p);
          const opacity = p;
          const scaleY = lerp(0.7, 1, p);

          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: x + xJit,
                top: y,
                width: LETTER_W,
                opacity,
                transform: `scaleY(${scaleY})`,
                transformOrigin: 'center bottom',
                textAlign: 'center',
                fontFamily: 'Cinzel, "Times New Roman", serif',
                fontSize: SIZE,
                fontWeight: 600,
                lineHeight: 1,
                color: 'transparent',
                background:
                  'linear-gradient(180deg, #fff4d2 0%, #ffd98a 28%, #f5c66b 50%, #b88030 75%, #f5c66b 100%)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                letterSpacing: 0,
                willChange: 'transform, opacity, top, left',
                filter:
                  'drop-shadow(0 4px 24px rgba(0,0,0,0.6)) drop-shadow(0 0 30px rgba(245,198,107,0.18))',
              }}
            >
              {ch}
            </div>
          );
        })}
      </div>
    );
  }

  // ── tagline (cinematic letter-spacing reveal) ────────────
  function Tagline({ time }) {
    const t = smoothstep(7.4, 9.0, time);
    const opacity = ease.outCubic(t);
    const exit = 1 - smoothstep(TRANSITION_START, TRANSITION_END - 0.4, time);
    const spacing = lerp(2, 16, t);

    return (
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 970,
          textAlign: 'center',
          opacity: opacity * exit,
          pointerEvents: 'none',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 28,
          }}
        >
          <div
            style={{
              width: 120,
              height: 1,
              background:
                'linear-gradient(90deg, rgba(245,198,107,0) 0%, rgba(245,198,107,0.85) 100%)',
            }}
          />
          <div
            style={{
              fontFamily: '"Space Grotesk", system-ui, sans-serif',
              fontSize: 30,
              fontWeight: 400,
              color: '#f1e3bf',
              letterSpacing: `${spacing}px`,
              paddingLeft: `${spacing}px`,
              textTransform: 'uppercase',
            }}
          >
            We see what others don't
          </div>
          <div
            style={{
              width: 120,
              height: 1,
              background:
                'linear-gradient(90deg, rgba(245,198,107,0.85) 0%, rgba(245,198,107,0) 100%)',
            }}
          />
        </div>
      </div>
    );
  }

  // ── HUD top-left ─────────────────────────────────────────
  function HudTopLeft({ time }) {
    const opacity = smoothstep(1.2, 2.6, time) * (1 - smoothstep(TRANSITION_START, TRANSITION_END - 0.3, time));
    const cycle = Math.floor(time * 1.5);
    const states = ['SCANNING', 'TRACKING', 'DECODING', 'RESOLVING'];
    const state = states[cycle % states.length];
    return (
      <div
        style={{
          position: 'absolute',
          left: 56,
          top: 48,
          opacity,
          fontFamily: '"JetBrains Mono", ui-monospace, monospace',
          fontSize: 13,
          color: GOLD,
          letterSpacing: '0.22em',
          lineHeight: 1.7,
          pointerEvents: 'none',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 7,
              height: 7,
              background: GOLD,
              boxShadow: `0 0 8px ${GOLD}`,
              opacity: 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(time * 4)),
            }}
          />
          <span>THANATOS // SYS_INIT</span>
        </div>
        <div style={{ color: 'rgba(245,198,107,0.55)', marginTop: 6 }}>
          STATUS:&nbsp;<span style={{ color: GOLD }}>{state}</span>
        </div>
      </div>
    );
  }

  function HudBottomRight({ time }) {
    const opacity = smoothstep(1.2, 2.6, time) * (1 - smoothstep(TRANSITION_START, TRANSITION_END - 0.3, time));
    const tStr = time.toFixed(2).padStart(5, '0');
    const code = Math.floor((time * 100) % 99999)
      .toString(16)
      .toUpperCase()
      .padStart(5, '0');
    return (
      <div
        style={{
          position: 'absolute',
          right: 56,
          bottom: 48,
          opacity,
          fontFamily: '"JetBrains Mono", ui-monospace, monospace',
          fontSize: 12,
          color: 'rgba(245,198,107,0.6)',
          textAlign: 'right',
          letterSpacing: '0.18em',
          lineHeight: 1.7,
          pointerEvents: 'none',
        }}
      >
        <div>FRAME 0x{code}</div>
        <div>T+{tStr}s</div>
        <div style={{ color: GOLD, marginTop: 6 }}>THANATOS.AGENCY</div>
      </div>
    );
  }

  // ── corner brackets ─────────────────────────────────────
  function CornerBrackets({ time }) {
    const opacity = smoothstep(0.9, 2.0, time) * (1 - smoothstep(TRANSITION_START, TRANSITION_END - 0.3, time));
    const arm = 32;
    const inset = 40;
    const Bracket = ({ x, y, hx, hy }) => (
      <g stroke={GOLD} strokeWidth={1.6} fill="none" opacity={0.6}>
        <line x1={x} y1={y} x2={x + arm * hx} y2={y} />
        <line x1={x} y1={y} x2={x} y2={y + arm * hy} />
      </g>
    );
    return (
      <svg
        width={W}
        height={H}
        viewBox={`0 0 ${W} ${H}`}
        style={{ position: 'absolute', inset: 0, opacity, pointerEvents: 'none' }}
      >
        <Bracket x={inset} y={inset} hx={1} hy={1} />
        <Bracket x={W - inset} y={inset} hx={-1} hy={1} />
        <Bracket x={inset} y={H - inset} hx={1} hy={-1} />
        <Bracket x={W - inset} y={H - inset} hx={-1} hy={-1} />
      </svg>
    );
  }

  // ── vignette (always on; darker in intro) ────────────────
  function Vignette({ strength = 1 }) {
    const inner = lerp(40, 25, strength);
    const mid = lerp(0.4, 0.6, strength);
    return (
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse at center, rgba(0,0,0,0) ${inner}%, rgba(0,0,0,${mid}) 75%, rgba(0,0,0,0.96) 100%)`,
          pointerEvents: 'none',
        }}
      />
    );
  }

  // ── grain ───────────────────────────────────────────────
  function Grain({ time }) {
    const shift = Math.floor(time * 60) % 8;
    return (
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.5 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`,
          backgroundSize: '160px 160px',
          backgroundPosition: `${shift * 7}px ${shift * 11}px`,
          opacity: 0.08,
          mixBlendMode: 'overlay',
          pointerEvents: 'none',
        }}
      />
    );
  }

  // ── home page (revealed after intro) ─────────────────────
  function HomePage({ visible, ambientTime, onReplay }) {
    if (!visible) return null;
    return (
      <div
        style={{
          position: 'absolute',
          inset: 0,
          pointerEvents: visible ? 'auto' : 'none',
          opacity: 1,
        }}
      >
        {/* Hero */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            paddingTop: 60,
            pointerEvents: 'none',
          }}
        >
          <div
            style={{
              fontFamily: '"JetBrains Mono", ui-monospace, monospace',
              fontSize: 13,
              letterSpacing: '0.4em',
              color: GOLD,
              textTransform: 'uppercase',
              marginBottom: 32,
              opacity: 0.7 + 0.3 * (0.5 + 0.5 * Math.sin(ambientTime * 1.4)),
            }}
          >
            ◇ Private Intelligence Bureau ◇
          </div>
          <div
            style={{
              fontFamily: 'Cinzel, "Times New Roman", serif',
              fontSize: 200,
              fontWeight: 500,
              letterSpacing: '14px',
              paddingLeft: 14,
              lineHeight: 1,
              color: 'transparent',
              background:
                'linear-gradient(180deg, #fff4d2 0%, #ffd98a 28%, #f5c66b 50%, #b88030 78%, #f5c66b 100%)',
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              filter:
                'drop-shadow(0 4px 24px rgba(0,0,0,0.6)) drop-shadow(0 0 30px rgba(245,198,107,0.15))',
            }}
          >
            THANATOS
          </div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 28,
              marginTop: 28,
            }}
          >
            <div
              style={{
                width: 140,
                height: 1,
                background:
                  'linear-gradient(90deg, rgba(245,198,107,0) 0%, rgba(245,198,107,0.8) 100%)',
              }}
            />
            <div
              style={{
                fontFamily: '"Space Grotesk", system-ui, sans-serif',
                fontSize: 26,
                color: '#f1e3bf',
                letterSpacing: '14px',
                paddingLeft: 14,
                textTransform: 'uppercase',
              }}
            >
              We see what others don't
            </div>
            <div
              style={{
                width: 140,
                height: 1,
                background:
                  'linear-gradient(90deg, rgba(245,198,107,0.8) 0%, rgba(245,198,107,0) 100%)',
              }}
            />
          </div>

          {/* Three pillars */}
          <div
            style={{
              display: 'flex',
              gap: 96,
              marginTop: 90,
              fontFamily: '"JetBrains Mono", ui-monospace, monospace',
              fontSize: 14,
              color: 'rgba(245,198,107,0.7)',
              letterSpacing: '0.22em',
              textTransform: 'uppercase',
            }}
          >
            <span>OSINT</span>
            <span style={{ color: 'rgba(245,198,107,0.35)' }}>◆</span>
            <span>Due Diligence</span>
            <span style={{ color: 'rgba(245,198,107,0.35)' }}>◆</span>
            <span>Cyber Investigation</span>
          </div>
        </div>

        {/* Replay button bottom-right */}
        <button
          onClick={onReplay}
          style={{
            position: 'absolute',
            right: 56,
            bottom: 48,
            padding: '12px 22px',
            background: 'rgba(20,15,5,0.7)',
            border: '1px solid rgba(245,198,107,0.35)',
            color: GOLD,
            fontFamily: '"JetBrains Mono", ui-monospace, monospace',
            fontSize: 12,
            letterSpacing: '0.24em',
            textTransform: 'uppercase',
            cursor: 'pointer',
            backdropFilter: 'blur(8px)',
          }}
        >
          ▶ Replay Intro
        </button>
      </div>
    );
  }

  // ── playback bar (only during intro) ─────────────────────
  function PlaybackBar({ time, duration, playing, onPlayPause, onReset, onSeek, onSkip }) {
    const trackRef = useRef(null);
    const [dragging, setDragging] = useState(false);
    const timeFromEvent = (e) => {
      const r = trackRef.current.getBoundingClientRect();
      return clamp((e.clientX - r.left) / r.width, 0, 1) * duration;
    };
    useEffect(() => {
      if (!dragging) return;
      const up = () => setDragging(false);
      const mv = (e) => onSeek(timeFromEvent(e));
      window.addEventListener('mouseup', up);
      window.addEventListener('mousemove', mv);
      return () => {
        window.removeEventListener('mouseup', up);
        window.removeEventListener('mousemove', mv);
      };
    }, [dragging]);
    const fmt = (t) => {
      const m = Math.floor(t / 60);
      const s = Math.floor(t % 60);
      const cs = Math.floor((t * 100) % 100);
      return `${m}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
    };
    return (
      <div
        style={{
          position: 'absolute',
          left: '50%',
          bottom: 18,
          transform: 'translateX(-50%)',
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '8px 14px',
          background: 'rgba(15,10,3,0.86)',
          border: '1px solid rgba(245,198,107,0.22)',
          borderRadius: 8,
          color: '#f6f4ef',
          fontFamily: '"JetBrains Mono", ui-monospace, monospace',
          fontSize: 12,
          width: 560,
          zIndex: 100,
          backdropFilter: 'blur(8px)',
        }}
      >
        <button onClick={onReset} title="Reset" style={btnStyle}>⏮</button>
        <button onClick={onPlayPause} title="Play/pause" style={btnStyle}>
          {playing ? '❚❚' : '▶'}
        </button>
        <div style={{ width: 56, textAlign: 'right', color: GOLD }}>{fmt(time)}</div>
        <div
          ref={trackRef}
          onMouseDown={(e) => {
            setDragging(true);
            onSeek(timeFromEvent(e));
          }}
          style={{
            flex: 1,
            height: 18,
            position: 'relative',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <div style={{ position: 'absolute', left: 0, right: 0, height: 3, background: 'rgba(245,198,107,0.15)', borderRadius: 2 }} />
          <div style={{ position: 'absolute', left: 0, width: `${(time / duration) * 100}%`, height: 3, background: GOLD, borderRadius: 2 }} />
          <div style={{ position: 'absolute', left: `${(time / duration) * 100}%`, width: 10, height: 10, marginLeft: -5, background: GOLD, borderRadius: 5, boxShadow: '0 0 8px rgba(245,198,107,0.7)' }} />
        </div>
        <div style={{ width: 56, color: 'rgba(245,198,107,0.6)' }}>{fmt(duration)}</div>
        <button onClick={onSkip} title="Skip" style={{...btnStyle, width: 'auto', padding: '0 10px'}}>SKIP ⏭</button>
      </div>
    );
  }

  const btnStyle = {
    width: 28,
    height: 28,
    background: 'transparent',
    border: '1px solid rgba(245,198,107,0.3)',
    color: GOLD,
    cursor: 'pointer',
    borderRadius: 4,
    fontFamily: '"JetBrains Mono", monospace',
    fontSize: 11,
  };

  // ── main component ───────────────────────────────────────
  function ThanatosIntro(props) {
    const logo = props.logo || './logo.png';

    const [mode, setMode] = useState(() => {
      try {
        return localStorage.getItem(STORAGE_KEY) === '1' ? 'home' : 'intro';
      } catch {
        return 'intro';
      }
    });

    const [time, setTime] = useState(0);
    const [ambientTime, setAmbientTime] = useState(0);
    const [playing, setPlaying] = useState(true);
    const [audioReady, setAudioReady] = useState(false);
    const [muted, setMuted] = useState(false);
    const lastTs = useRef(null);
    const ambLastTs = useRef(null);
    const rafRef = useRef(null);
    const ambRafRef = useRef(null);
    const stageRef = useRef(null);
    const [scale, setScale] = useState(1);
    const audioRef = useRef(null);
    const lastCueIdxRef = useRef(-1);

    // init audio engine once
    if (!audioRef.current) audioRef.current = new AudioEngine();

    // fire cues when time crosses thresholds
    useEffect(() => {
      if (mode !== 'intro') return;
      const a = audioRef.current;
      if (!a || !a.ctx) return;
      // find highest cue idx that has fired
      for (let i = lastCueIdxRef.current + 1; i < CUES.length; i++) {
        const c = CUES[i];
        if (time >= c.t) {
          if (c.name === 'drone') a.startDrone();
          else if (c.name === 'shimmer') a.shimmer();
          else if (c.name === 'whoosh') a.whoosh();
          else if (c.name === 'chime') a.chime();
          else if (c.name === 'tick') a.tick(c.idx);
          else if (c.name === 'bass') a.bassImpact();
          else if (c.name === 'highsweep') a.highSweep();
          else if (c.name === 'transitionwhoosh') a.transitionWhoosh();
          else if (c.name === 'stopdrone') a.stopDrone(1.5);
          else if (c.name === 'settle') a.settle();
          lastCueIdxRef.current = i;
        } else break;
      }
    }, [time, mode]);

    // when scrub backwards, reset cue index
    useEffect(() => {
      if (mode !== 'intro') return;
      // if time jumped back, reset firing index to nearest below
      let i = -1;
      for (let k = 0; k < CUES.length; k++) if (CUES[k].t <= time) i = k;
      if (i < lastCueIdxRef.current) lastCueIdxRef.current = i;
    }, [time, mode]);

    // intro RAF (only when intro and playing)
    useEffect(() => {
      if (mode !== 'intro' || !playing) {
        lastTs.current = null;
        return;
      }
      let cancelled = false;
      const step = (ts) => {
        if (cancelled) return;
        if (lastTs.current == null) lastTs.current = ts;
        const dt = Math.min(0.1, (ts - lastTs.current) / 1000);
        lastTs.current = ts;
        setTime((t) => {
          const n = t + dt;
          if (n >= INTRO_DURATION) {
            // mark seen + switch to home
            try { localStorage.setItem(STORAGE_KEY, '1'); } catch {}
            // schedule mode switch after current update
            queueMicrotask(() => setMode('home'));
            return INTRO_DURATION;
          }
          return n;
        });
        rafRef.current = requestAnimationFrame(step);
      };
      rafRef.current = requestAnimationFrame(step);
      return () => {
        cancelled = true;
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        lastTs.current = null;
      };
    }, [mode, playing]);

    // ambient RAF (always running, for home + grain in intro)
    useEffect(() => {
      let cancelled = false;
      const step = (ts) => {
        if (cancelled) return;
        if (ambLastTs.current == null) ambLastTs.current = ts;
        const dt = Math.min(0.1, (ts - ambLastTs.current) / 1000);
        ambLastTs.current = ts;
        setAmbientTime((t) => t + dt);
        ambRafRef.current = requestAnimationFrame(step);
      };
      ambRafRef.current = requestAnimationFrame(step);
      return () => {
        cancelled = true;
        if (ambRafRef.current) cancelAnimationFrame(ambRafRef.current);
        ambLastTs.current = null;
      };
    }, []);

    // scale fit
    useEffect(() => {
      const el = stageRef.current;
      if (!el) return;
      const measure = () => {
        const cw = Math.max(el.clientWidth, window.innerWidth || 0);
        const ch = Math.max(el.clientHeight, window.innerHeight || 0);
        if (cw <= 0 || ch <= 0) return;
        const s = Math.min(cw / W, ch / H);
        if (isFinite(s) && s > 0) setScale(s);
      };
      requestAnimationFrame(measure);
      requestAnimationFrame(() => requestAnimationFrame(measure));
      setTimeout(measure, 0);
      setTimeout(measure, 100);
      const ro = new ResizeObserver(measure);
      ro.observe(el);
      window.addEventListener('resize', measure);
      return () => {
        ro.disconnect();
        window.removeEventListener('resize', measure);
      };
    }, []);

    useEffect(() => {
      const onKey = (e) => {
        if (mode !== 'intro') return;
        if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
        if (e.code === 'Space') { e.preventDefault(); setPlaying((p) => !p); }
        else if (e.code === 'ArrowLeft') setTime((t) => clamp(t - (e.shiftKey ? 1 : 0.1), 0, INTRO_DURATION));
        else if (e.code === 'ArrowRight') setTime((t) => clamp(t + (e.shiftKey ? 1 : 0.1), 0, INTRO_DURATION));
        else if (e.key === '0') setTime(0);
        else if (e.key === 'Escape') skipIntro();
      };
      window.addEventListener('keydown', onKey);
      return () => window.removeEventListener('keydown', onKey);
    }, [mode]);

    const replayIntro = async () => {
      setTime(0);
      lastCueIdxRef.current = -1;
      const a = audioRef.current;
      if (a) {
        a.stopDrone(0.2);
        const ok = await a.resume();
        setAudioReady(ok);
      }
      setPlaying(true);
      setMode('intro');
    };

    const skipIntro = () => {
      try { localStorage.setItem(STORAGE_KEY, '1'); } catch {}
      const a = audioRef.current;
      if (a) a.stopDrone(0.4);
      setTime(INTRO_DURATION);
      setMode('home');
    };

    const enableAudio = async () => {
      const a = audioRef.current;
      if (!a) return;
      const ok = await a.resume();
      a.setMuted(false);
      setMuted(false);
      setAudioReady(ok);
      // restart playback from start to sync sound to visuals
      setTime(0);
      lastCueIdxRef.current = -1;
      setPlaying(true);
    };

    const toggleMute = async () => {
      const a = audioRef.current;
      if (!a) return;
      if (!audioReady) {
        await enableAudio();
        return;
      }
      const next = !muted;
      a.setMuted(next);
      setMuted(next);
    };

    // cleanup audio on unmount
    useEffect(() => {
      return () => {
        const a = audioRef.current;
        if (a) {
          a.stopDrone(0.1);
          try { a.ctx && a.ctx.close(); } catch (e) {}
        }
      };
    }, []);

    // camera push-in throughout intro
    const cameraPush = mode === 'intro'
      ? lerp(1.0, 1.12, ease.inOutCubic(smoothstep(0, INTRO_DURATION - 1.5, time)))
      : 1.0;

    // post-transition home reveal
    const introActive = mode === 'intro';
    const homeReveal = mode === 'home'
      ? 1
      : smoothstep(TRANSITION_START + 0.4, TRANSITION_END, time);

    const labelSec = mode === 'intro' ? Math.floor(time) : -1;

    return (
      <div
        ref={stageRef}
        data-screen-label={mode === 'intro' ? `Thanatos Intro · t=${labelSec}s` : 'Thanatos Home'}
        style={{
          position: 'absolute',
          inset: 0,
          background: VOID,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            width: W,
            height: H,
            flex: 'none',
            flexShrink: 0,
            transform: `scale(${scale})`,
            transformOrigin: 'center',
            position: 'relative',
            overflow: 'hidden',
            background: 'radial-gradient(ellipse at 50% 45%, #050402 0%, #020201 60%, #000 100%)',
          }}
        >
          {/* Camera-push wrapper for intro scene */}
          {mode === 'intro' && (
            <div
              style={{
                position: 'absolute',
                inset: 0,
                transform: `scale(${cameraPush})`,
                transformOrigin: 'center',
                willChange: 'transform',
              }}
            >
              <Beam time={time} />
              <CoreGlow time={time} />
              <StreamingParticles time={time} />
              <Rings time={time} />
              <ScanSweep time={time} />
              <Wordmark time={time} />
              <Tagline time={time} />
              <CornerBrackets time={time} />
              <HudTopLeft time={time} />
              <HudBottomRight time={time} />
            </div>
          )}

          {/* Home page underneath — reveals at end of intro */}
          <div style={{ opacity: homeReveal, transition: 'none' }}>
            <AmbientStars time={ambientTime} intensity={0.7} />
            <HomePage visible={mode === 'home' || homeReveal > 0} ambientTime={ambientTime} onReplay={replayIntro} />
          </div>

          {/* Logo (shared element) */}
          <Logo time={time} logo={logo} mode={mode} />

          {/* Vignette + grain over everything */}
          <Vignette strength={mode === 'intro' ? 1 : 0.55} />
          <Grain time={mode === 'intro' ? time : ambientTime} />
        </div>

        {mode === 'intro' && (
          <PlaybackBar
            time={time}
            duration={INTRO_DURATION}
            playing={playing}
            onPlayPause={() => setPlaying((p) => !p)}
            onReset={() => { setTime(0); lastCueIdxRef.current = -1; }}
            onSeek={(t) => setTime(t)}
            onSkip={skipIntro}
          />
        )}

        {/* Audio gate — shown over intro until user clicks (browsers require gesture) */}
        {mode === 'intro' && !audioReady && (
          <div
            onClick={enableAudio}
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'rgba(0,0,0,0.55)',
              backdropFilter: 'blur(6px)',
              cursor: 'pointer',
              zIndex: 200,
            }}
          >
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 22,
                padding: '32px 44px',
                border: '1px solid rgba(245,198,107,0.35)',
                background: 'rgba(15,10,3,0.85)',
                color: GOLD,
                fontFamily: '"JetBrains Mono", ui-monospace, monospace',
                letterSpacing: '0.28em',
                textTransform: 'uppercase',
              }}
            >
              <div style={{ fontSize: 42, lineHeight: 1 }}>♪</div>
              <div style={{ fontSize: 14 }}>Enter with sound</div>
              <div style={{ fontSize: 10, color: 'rgba(245,198,107,0.55)', letterSpacing: '0.22em' }}>
                Click anywhere to begin
              </div>
            </div>
          </div>
        )}

        {/* Mute toggle — present once audio is enabled */}
        {audioReady && (
          <button
            onClick={toggleMute}
            title={muted ? 'Unmute' : 'Mute'}
            style={{
              position: 'absolute',
              right: mode === 'intro' ? 56 : 56,
              top: 48,
              width: 40,
              height: 40,
              background: 'rgba(15,10,3,0.7)',
              border: '1px solid rgba(245,198,107,0.3)',
              borderRadius: 4,
              color: GOLD,
              fontSize: 16,
              cursor: 'pointer',
              fontFamily: '"JetBrains Mono", ui-monospace, monospace',
              zIndex: 90,
              backdropFilter: 'blur(8px)',
            }}
          >
            {muted ? '🔇' : '🔊'}
          </button>
        )}
      </div>
    );
  }

  window.ThanatosIntro = ThanatosIntro;
})();
