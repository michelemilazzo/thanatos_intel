# Handoff: Thanatos.agency — Cinematic Site Intro

## Overview
Cinematic "first visit" intro overlay for **thanatos.agency** (Private Intelligence Bureau).
A 12.5-second dark, golden, cinematic reveal that plays the first time a user lands on the site, then dissolves into the home page — the central logo morphs into the home header's small logo as the home content fades in underneath. After the first play it is skipped on subsequent visits (persisted in `localStorage`). A "Replay Intro" button on the home page re-triggers it.

Story arc (12.5s, in order):
1. **0–2s** — Pure void, faint core of light begins to glow at center
2. **2–4s** — Outer ring traces, vertical light beam appears, scan-line sweeps the frame, particles begin streaming radially outward from center (hyperspace effect)
3. **3–5s** — Logo materializes at the center with warm gold glow, inner dashed ring counter-rotates, orbiting sweep-dots ride the rings
4. **5–7.5s** — Monumental "THANATOS" wordmark assembles letter-by-letter, alternating letters slide in from above/below
5. **7.5–9s** — Tagline "WE SEE WHAT OTHERS DON'T" reveals with hairline divider lines
6. **9–10.5s** — Hold, breathe (subtle scale pulse on logo + glow)
7. **10.5–12s** — Transition: logo translates + scales toward home header's top-left position, intro elements fade, home page reveals beneath, final fade-to-home

Throughout: subtle continuous **camera push-in** (scene scales from 1.0 to 1.12), continuous ring rotation, film grain overlay, vignette.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype that demonstrates the intended look, motion, timing, and behavior. **They are not production code to copy directly.**

Your task is to **recreate this intro in the target codebase's existing environment** (Next.js, Astro, plain React, Vue, etc.) using its established patterns. If thanatos.agency has no frontend framework yet, choose the most appropriate one for the project (Next.js + React is a safe default for an agency marketing site) and implement the design there.

The prototype is a single React component using `React.createElement`-style scenes driven by a single time variable in state, advanced via `requestAnimationFrame`. You can keep that architecture, or convert to:
- Framer Motion + React (recommended for React/Next.js)
- GSAP timelines (framework-agnostic, easy to fine-tune)
- CSS-only animations (lightest, less control over the dissolve-to-home morph)

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, motion timings and easings are intentional and should be matched. The home page shown after the dissolve is a placeholder hero — replace with the real Thanatos home, but **keep the logo morph target position** (top-left, ~56×56px logo, 56px from top and 56px from left edge at 1920×1080) so the dissolve aligns with the real header.

## Screens / Views

### 1. Intro Overlay (full viewport, fixed)
- **Purpose**: First-visit cinematic load.
- **Layout**: Full viewport, fixed position, z-index above all content. Internal stage is **1920×1080** uniformly scaled to fit the viewport (`min(vw/1920, vh/1080)`), centered.
- **Background**: `radial-gradient(ellipse at 50% 45%, #050402 0%, #020201 60%, #000 100%)` over solid `#000`.
- **Layers (back to front)**:
  1. Background radial gradient
  2. Camera-push wrapper (scale 1.0 → 1.12 over the 12s)
  3. Volumetric beam (vertical golden light shaft)
  4. Core glow (large radial gold glow behind logo)
  5. Streaming particles (140 particles radiating from center)
  6. Rotating rings (SVG) — outer solid, inner dashed, far faint
  7. Scan-line sweep (one-time vertical pass)
  8. Wordmark "THANATOS" (8 separate letter elements)
  9. Tagline
  10. Corner brackets (SVG, 4 corners)
  11. HUD text top-left + bottom-right
  12. Vignette
  13. Film grain (overlay blend, 8% opacity)

#### Key components

**Logo (shared element)**
- Source: `logo.png` (Thanatos eye-in-pyramid mark)
- Intro position: center-x, y=460 (in 1920×1080 space), size 420×420
- Home position: x=56+28, y=56+28, size 56×56
- During transition (10.5s → 12.0s): linearly interpolated via `inOutCubic` easing on all four properties (x, y, w, h)
- Entry animation (2.8s → 4.8s): opacity 0→1 (outCubic), scale 0.6→1.0, rotate -18deg→0deg
- Filter: `drop-shadow(0 0 24px rgba(245,198,107,0.6)) drop-shadow(0 0 64px rgba(245,198,107,0.3))` — glow intensity reduces during transition to home position
- Subtle breathe: `scale(1 + 0.012 * sin(t * 1.2))`

**Wordmark "THANATOS"**
- Font: **Cinzel 600**, 260px, lineHeight 1
- Color: vertical gradient text fill `linear-gradient(180deg, #fff4d2 0%, #ffd98a 28%, #f5c66b 50%, #b88030 75%, #f5c66b 100%)` clipped to text
- Filter: `drop-shadow(0 4px 24px rgba(0,0,0,0.6)) drop-shadow(0 0 30px rgba(245,198,107,0.18))`
- Layout: 8 letters absolutely positioned, each `width = 260 * 0.62 ≈ 161px`, centered horizontally as a row, baseline y = 770
- Per-letter motion (stagger 0.13s starting at t=4.8s, duration 1.0s, `outQuart` easing):
  - Even-indexed letters slide DOWN from y = baseline - 260
  - Odd-indexed letters slide UP from y = baseline + 260
  - Horizontal drift: each letter starts offset by `(i - 3.5) * 28px` from final x and converges
  - scaleY: 0.7 → 1.0
  - Opacity: 0 → 1

**Tagline**
- Text: `WE SEE WHAT OTHERS DON'T` (Italian alt: `NOI VEDIAMO CIÒ CHE GLI ALTRI NON VEDONO`)
- Font: **Space Grotesk 400**, 30px, uppercase
- Color: `#f1e3bf`
- Letter-spacing: animates 2px → 16px (matching `paddingLeft` so the text stays optically centered)
- Flanked by two 120px hairline gradient lines: `linear-gradient(90deg, transparent → rgba(245,198,107,0.85))` on left, mirrored on right
- Position: y = 970, full-width centered, gap 28px between dividers and text
- Reveal: 7.4s → 9.0s (outCubic)

**Rings (SVG, viewBox 1920×1080)**
- Center at (960, 460)
- **Outer ring**: r=380, stroke 1.4px, fill `url(#ringGrad)` (linearGradient with stops: transparent → #ffd98a → #b88030 → transparent), trace via `strokeDasharray = 2πr; strokeDashoffset = circumference * (1 - progress)`, progress eased `outQuart` from t=1.6 to t=3.6. Continuously rotates: `-90deg + t * 5°/s`.
- **Inner dashed ring**: r=310, stroke 1px `rgba(245,198,107,0.55)`, dasharray `2 10`, counter-rotates at `-18°/s`, traces t=2.2 → 4.2.
- **Far faint ring**: r=460, stroke 0.8px `rgba(245,198,107,0.18)`, dasharray `1 6`, counter-rotates at `-8°/s`, traces t=3.0 → 5.0.
- **8 tick marks** at 0°, 45°, 90°, ... around outer ring (major at 90° intervals are 1.5px stroke; minor 0.8px). Inner end at r-10, outer end at r+12. Reveal t=3.6 → 5.5.
- **Orbiting sweep dots**:
  - Primary: on outer ring, rotates `t * 110°/s` clockwise. Glow circle (r=14, `url(#sweepGrad)` radial) + bright core (r=3.5, `#ffd98a`). Reveal t=3.8 → 4.6.
  - Secondary: on inner ring, rotates `-t * 77°/s + 180°` offset, 70% opacity, smaller (r=9 glow + r=2 core). Reveal t=4.2 → 5.0.

**Streaming particles (radial hyperspace)**
- 140 particles, seeded so positions are deterministic
- Each has: angle (0-2π), startDist (0-80px), speed (0.18-0.58 cycles/s), phase, base size (1-3.5px)
- Per particle, per frame: cycle = `((t * speed + phase) % 3.5) / 3.5` → distNorm 0..1
- `dist = startDist + distNorm * 1100`, position = center + `(cos(angle) * dist, sin(angle) * dist * 0.62)` (vertical squash for parallax)
- Rendered as gold dots with size `baseSize * (0.25 + distNorm * 2.2)` and box-shadow glow
- Fade in early (`distNorm < 0.08`), fade out at edge (`distNorm > 0.85`)
- Group opacity: smoothstep(0.6, 3.0, t) reveal, fade out during transition

**Beam (vertical light shaft)**
- Centered horizontally at x=960, full height, width 520
- Background: `radial-gradient(ellipse 260px 620px at 50% 45%, rgba(245,198,107,0.22), transparent 70%)`
- Sway: rotates `sin(t * 0.5) * 8deg` around top-center
- Pulse opacity: `0.7 + 0.3 * sin(t * 1.4)`
- Reveals 2.0s → 4.0s, fades during transition
- `mix-blend-mode: screen`, `filter: blur(2px)`

**Core glow**
- 1120×1120 radial gradient centered behind logo
- `radial-gradient(circle, rgba(245,198,107,0.55) 0%, 0.22 20%, 0.05 42%, 0 62%)`
- Breathe: `scale(1 + 0.06 * sin(t * 1.3))`
- Initial seed glow t=0.4 → 1.6 (at 50% intensity), then full reveal 2.5 → 5.0
- `mix-blend-mode: screen`, `filter: blur(10px)`

**Scan sweep**
- One-time vertical pass between t=2.4s and t=3.8s
- 160px tall horizontal band, y interpolated from -60 to H+60
- Background: `linear-gradient(180deg, transparent, rgba(245,198,107,0.22) 50%, transparent)`
- Opacity peaks mid-sweep: `(1 - |2p - 1|) * 0.55`

**Corner brackets**
- L-shaped marks at the 4 corners, 40px inset, 32px arm length
- Stroke `#f5c66b` 1.6px, opacity 0.6
- Reveal 0.9s → 2.0s, fade out during transition

**HUD text — top-left** (`#f5c66b`, JetBrains Mono 13px, letterSpacing 0.22em)
- Animated dot indicator (7×7px, pulsing opacity)
- Line 1: `THANATOS // SYS_INIT`
- Line 2: `STATUS: <SCANNING|TRACKING|DECODING|RESOLVING>` (cycles every ~0.67s)
- Reveal 1.2s → 2.6s

**HUD text — bottom-right** (right-aligned, JetBrains Mono 12px, letterSpacing 0.18em, `rgba(245,198,107,0.6)`)
- `FRAME 0x<5-hex-digit>` (cycles with time)
- `T+<seconds.cs>s`
- `THANATOS.AGENCY` (in solid gold)

**Vignette**
- `radial-gradient(ellipse at center, transparent 25%, rgba(0,0,0,0.6) 75%, rgba(0,0,0,0.96) 100%)`
- Intro: full strength. Home: reduced (innerStop 40%, midAlpha 0.4).

**Film grain**
- SVG turbulence noise texture, 160×160 tile, `mix-blend-mode: overlay`, 8% opacity
- Position shifts every frame (using `floor(t * 60) % 8` modulated x/y) to animate the grain

### 2. Home Page (revealed under intro)
Placeholder that becomes the real home in production. Implements:
- **Header** (fixed top): logo space at top-left (the morphed intro logo lands here), wordmark "THANATOS" Cinzel 26px letterSpacing 0.28em, right-aligned nav `SERVICES · CASES · METHOD · CONTACT` in JetBrains Mono 13px
- **Hero center**: small ornamental label "◇ PRIVATE INTELLIGENCE BUREAU ◇" (gold, monospaced, pulsing opacity), giant "THANATOS" 200px Cinzel with the same gold gradient, tagline with hairline dividers, three pillars row `OSINT ◆ DUE DILIGENCE ◆ CYBER INVESTIGATION`
- **Ambient stars** (50 faint twinkling particles) in background
- **"▶ REPLAY INTRO" button** bottom-right (gold border, dark backdrop, JetBrains Mono caps)

## Interactions & Behavior

### First-visit gate
On mount, check `localStorage.getItem('thanatos_intro_seen')`:
- If `'1'` → skip intro, show home immediately.
- Otherwise → play intro from t=0. When time reaches `INTRO_DURATION (12.5s)`, set `localStorage.setItem('thanatos_intro_seen', '1')` and switch to home mode.

In production you should also consider a session-based key so the intro plays again after some time has passed (e.g. cookie with 7-day expiry), or a query-param override `?intro=1` to force-replay for QA.

### Skip controls (intro mode only)
- **ESC** key: skip immediately (jump to end + mark seen)
- **Click "SKIP ⏭"** button on the playback bar
- **Click "▶ REPLAY INTRO"** on the home page: reset time to 0, switch back to intro mode (does NOT clear the "seen" flag)

### Playback controls (only present in this prototype, remove in production)
The playback bar at the bottom (play/pause, scrubber, reset, skip, keyboard ←/→ scrub) is for design review only and **must be removed in the production build**. Production should expose only:
- ESC = skip
- Auto-advance to home at end

### Animation engine
Single `time` state advanced by `requestAnimationFrame`. Each frame:
- dt is computed and clamped to 0.1s max (prevents jumps after tab-throttle resume)
- All scene components receive `time` as a prop and compute their visual state purely from it (no per-component state). This makes the timeline deterministic and trivially scrubbable.
- A separate `ambientTime` RAF runs always (for home page twinkles and grain).

### Easing functions
- `smoothstep(e0, e1, x)` = clamped `t² * (3 - 2t)` interpolation, used as the base "between-times" reveal curve everywhere
- `outCubic`, `outQuart`, `outExpo`, `inOutCubic` for explicit easings on hero transitions

## State Management

| State | Type | Purpose |
|---|---|---|
| `mode` | `'intro' \| 'home'` | Top-level switch. Initialized from `localStorage`. |
| `time` | `number` (seconds, 0–12.5) | Intro playhead. Advanced by RAF when `mode === 'intro' && playing`. |
| `ambientTime` | `number` (seconds, ever-increasing) | Drives home-page twinkles + grain. Always running. |
| `playing` | `boolean` | Pause flag (prototype-only). Remove in production. |
| `scale` | `number` | Viewport-fit factor for the 1920×1080 stage. |

Transitions:
- `time` reaches `INTRO_DURATION` → write localStorage, set `mode = 'home'`
- Replay button clicked → `time = 0`, `mode = 'intro'`, `playing = true`
- ESC pressed (intro mode) → write localStorage, set `mode = 'home'`

## Design Tokens

### Colors
| Token | Hex | Use |
|---|---|---|
| `--gold` | `#f5c66b` | Primary gold (rings, HUD, dividers, logo glow) |
| `--gold-bright` | `#ffd98a` | Highlights, gradient mid-stops, glow cores |
| `--gold-deep` | `#b88030` | Gradient dark-stop on rings + wordmark |
| `--gold-pale` | `#fff4d2` | Top stop of wordmark gradient |
| `--text-cream` | `#f1e3bf` | Tagline body text |
| `--void` | `#000000` | Background base |
| `--void-warm-1` | `#050402` | Background radial center |
| `--void-warm-2` | `#020201` | Background radial mid |

### Typography
| Family | Weight | Use |
|---|---|---|
| **Cinzel** | 500–600 | Wordmark, hero headings |
| **Space Grotesk** | 300–500 | Tagline, body text |
| **JetBrains Mono** | 400–500 | HUD, nav, technical labels |

Load via Google Fonts:
```html
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600&family=Space+Grotesk:wght@300;400;500&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

### Typographic scale (at 1920×1080 reference)
- Wordmark (intro): 260px Cinzel 600
- Wordmark (home hero): 200px Cinzel 500, letterSpacing 14px
- Tagline: 30px Space Grotesk 400, uppercase
- Nav / HUD body: 13px JetBrains Mono 400, letterSpacing 0.22–0.28em uppercase
- HUD small: 12px JetBrains Mono, letterSpacing 0.18em

### Spacing & geometry
- Stage: 1920 × 1080
- Logo intro center: (960, 460)
- Logo home target: (84, 84) center → top-left header
- Header height: 112px
- Corner bracket inset: 40px, arm 32px
- Frame edge padding: 56px

### Timings (seconds, in intro)
```
0.0  Start (void)
0.4  Core glow seed appears
1.2  HUD reveal begins
1.6  Outer ring begins tracing
2.0  Beam reveal begins
2.4  Scan-line sweep begins
2.5  Core glow main reveal begins
2.8  Logo entry begins
3.8  Sweep dots appear
4.8  Wordmark first letter begins
6.0  Wordmark fully assembled
7.4  Tagline reveal begins
9.0  All elements settled
10.5 Transition to home begins (logo morph)
12.0 Home fully revealed
12.5 Intro ends, locked
```

### Easing reference
- All reveals use `smoothstep(start, end, t)` as the base curve.
- Wordmark letters: `outQuart`.
- Logo entry: `outCubic`.
- Logo morph to home: `inOutCubic`.

## Assets
- **`logo.png`** — Thanatos eye-in-pyramid mark (gold on dark). This is the same icon used in the production site favicon (`thanatos-icon-192.png`). 192×192 is sufficient.
- No other raster assets. Everything else (rings, particles, beams, brackets, grain) is generated procedurally via SVG/CSS.

## Files in this package
- `Thanatos Intro.dc.html` — the design source (a Design Component file). This wraps the actual implementation, which is `intro.jsx`.
- `intro.jsx` — **the actual implementation**. A self-executing IIFE that exposes `window.ThanatosIntro` (a React component). All scene components, easing utilities, animation engine, and the home-page placeholder live here. Read this file as the source of truth.
- `Thanatos Intro.html` — a fully self-contained, bundled, single-file version. You can open this directly in a browser to see the intro running. Use it for review only.
- `logo.png` — the Thanatos logo asset.

## Recommended implementation path (Next.js + React)
1. Drop `logo.png` into `/public`.
2. Create `components/ThanatosIntro/` and port `intro.jsx` to a proper TSX component:
   - Convert the IIFE wrapper away; just `export default function ThanatosIntro(...)`.
   - Split the inner scene components into separate files (`Logo.tsx`, `Wordmark.tsx`, `Rings.tsx`, etc.) — they're already cleanly decomposed.
   - Replace inline `setState` + RAF with `useAnimationFrame` from Framer Motion or a small custom hook.
3. Mount on the root layout (`app/layout.tsx`) as an overlay above page content, gated on a client-side localStorage check (use `useEffect` after mount to avoid SSR hydration mismatch).
4. Replace the placeholder `HomePage` component in `intro.jsx` with your real home page — but make sure the home header logo lands at the same pixel position the intro morphs to, so the dissolve is seamless.
5. Remove the `PlaybackBar`. Keep only ESC-to-skip.
6. Test with `?intro=1` query param to force-replay during development.

## Accessibility
- Honor `prefers-reduced-motion: reduce`: skip the intro entirely (show home immediately).
- Ensure the SKIP control is keyboard-focusable and reachable from the first frame.
- The intro contains no semantic content the user needs to read; the home page should be the source of truth for screen readers. Consider rendering the intro inside `aria-hidden="true"` and the home page underneath always present in the DOM (just visually covered) so SR users get the home immediately.

## Performance notes
- 140 streaming particles + 50 ambient + grain + glows = ~250 absolutely-positioned DOM nodes. This runs fine on modern desktops but may stutter on low-end mobile.
- For mobile, consider: reducing particle count to ~60, lowering grain opacity, or skipping the intro on `(max-width: 768px)`.
- All animations are CSS transform/opacity-friendly; no layout thrash.
