# Claude Code prompt — Thanatos intro su michelemilazzo/thanatos_intel

Apri Claude Code nel repo `thanatos_intel`, assicurati che la cartella `design_handoff_thanatos_intro/` sia presente alla root (estratta dallo ZIP) e incolla **esattamente questo prompt**:

---

```
Ho aggiunto la cartella `design_handoff_thanatos_intro/` al repo. Contiene il design
di un'intro cinematografica per la home di thanatos.agency (body.thanatos-home,
servita da thanatos_intel/www/index.html).

Leggi PRIMA in ordine:
1. design_handoff_thanatos_intro/frappe/INTEGRATION.md — guida specifica per questo repo Frappe
2. design_handoff_thanatos_intro/README.md — specifica visiva/audio completa
3. design_handoff_thanatos_intro/frappe/thanatos_intro.js — la build vanilla da deployare

TASK
Esegui l'integrazione descritta in INTEGRATION.md, esattamente 3 step:

A) Copia il file:
   cp design_handoff_thanatos_intro/frappe/thanatos_intro.js \
      thanatos_intel/public/js/thanatos_intro.js

B) In thanatos_intel/hooks.py, aggiungi
   '/assets/thanatos_intel/js/thanatos_intro.js'
   nella lista web_include_js, mantenendo le voci esistenti (fx_widget.js,
   thanatos_login.js).

C) NESSUNA modifica a www/index.html è necessaria — lo script si auto-installa
   quando vede body.thanatos-home.

VERIFICA prima del commit
- Apri thanatos_intel/public/js/thanatos_intro.js e conferma:
  * Brand colors corretti (GOLD = '#C8A96E', GOLD_BRIGHT = '#E0C58A')
  * Path logo = /assets/thanatos_intel/images/thanatos-logo-mark.png (esiste già)
  * Font Cinzel Decorative usato (già caricato in www/index.html)
- Lancia `bench build --app thanatos_intel` localmente
- Apri il sito in dev: l'intro deve partire alla home con il gate
  "ENTER WITH SOUND". Cliccando, parte l'animazione 12.5s sincronizzata con audio.
- Verifica che il logo finale "atterri" sopra al logo del hero (.t-hero-logo img)
  con un morph fluido.
- Refresh: intro non riparte; appare il bottone "▶ Replay intro" in basso a destra.
- Test con ?intro=1: forza il replay anche se localStorage è settato.

PRIMA di committare dimmi:
1. Diff esatto su hooks.py
2. Se vedi conflitti con altri overlay/modal su body.thanatos-home
3. Se il morph target (.t-hero-logo img) corrisponde davvero a dove vuoi che
   atterri il logo, o se preferisci un'altra ancora
4. Eventuali domande sulla brand alignment (gold tone, font, dimensioni wordmark)
```

---

## Tre modi per consegnargli il pacchetto

### A — Commit nel repo (consigliato, ti permette di versionarlo)
```bash
cd thanatos_intel
unzip ~/Downloads/design_handoff_thanatos_intro.zip
git add design_handoff_thanatos_intro/
git commit -m "Add Thanatos intro design handoff"
git push
```
Poi apri Claude Code nel repo e incolla il prompt qui sopra.

### B — Branch dedicato
```bash
cd thanatos_intel
git checkout -b design/intro
unzip ~/Downloads/design_handoff_thanatos_intro.zip
git add design_handoff_thanatos_intro/
git commit -m "Design handoff: cinematic intro"
git push -u origin design/intro
```
Più sicuro se vuoi tenere main pulito mentre Claude Code lavora.

### C — Solo i file finali
Se preferisci dare a Claude Code solo il JS pronto senza la documentazione:
```bash
cd thanatos_intel
cp ~/Downloads/.../frappe/thanatos_intro.js thanatos_intel/public/js/
# Modifica hooks.py a mano per aggiungere il path
bench build --app thanatos_intel
git add thanatos_intel/public/js/thanatos_intro.js thanatos_intel/hooks.py
git commit -m "feat(home): cinematic intro overlay"
git push
```
Nessun Claude Code necessario in questo caso.

## Dopo il deploy

- Reset state per testare daccapo: `localStorage.removeItem('thanatos_intro_seen')` in DevTools.
- Force replay: `?intro=1` in URL.
- Disable temporaneo: rimuovi la riga da `hooks.py`, rebuild.

## Iterazioni future con Claude Code

Quando vorrai modificare l'intro chiedi a Claude Code di lavorare direttamente
su `thanatos_intel/public/js/thanatos_intro.js`. Cose comuni:

- "Riduci la durata da 12.5s a 9s" → cambia `INTRO_DURATION` + scala tutti i
  timing nelle funzioni `build*`.
- "Cambia tagline" → cerca `"We see what others don't"` e sostituisci.
- "Cambia gold tone" → cambia `GOLD`, `GOLD_BRIGHT`, `GOLD_RGB` in cima al file.
- "Aggiungi versione italiana" → duplica il file in `thanatos_intro_it.js`
  e cambia tagline + serve dinamicamente in base a `frappe.lang`.
- "Disattiva audio di default" → cambia `muted` initial value a `true` in
  `AudioEngine` o aggiungi `audio.setMuted(true)` prima di `audio.resume()`.
