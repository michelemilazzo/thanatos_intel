# Thanatos Intro — Frappe v16 integration guide

**Target repo:** `michelemilazzo/thanatos_intel`
**Target stack:** Frappe v16 / ERPNext, server-side Jinja templates in `thanatos_intel/www/`, static assets in `thanatos_intel/public/`.
**Target page:** the home `thanatos_intel/www/index.html` (served as `/`), which already sets `body.thanatos-home` and has the gold/navy brand system.

This package contains a **vanilla JS port** of the React prototype, ready to drop into the Frappe app with **3 file changes**.

## What you ship

```
thanatos_intel/public/js/thanatos_intro.js     ← new file (this folder: frappe/thanatos_intro.js)
thanatos_intel/hooks.py                        ← add ONE entry to web_include_js
thanatos_intel/www/index.html                  ← no change needed (auto-detects body.thanatos-home)
```

That's it. The script is fully self-contained: animation, audio, gating, replay button, mute toggle, ESC-to-skip.

## Step-by-step

### 1. Copy the JS

```bash
cp design_handoff_thanatos_intro/frappe/thanatos_intro.js \
   thanatos_intel/public/js/thanatos_intro.js
```

### 2. Register it in `hooks.py`

Find this block in `thanatos_intel/hooks.py`:

```python
web_include_js=['/assets/thanatos_intel/js/fx_widget.js', '/assets/thanatos_intel/js/thanatos_login.js']
```

Add `/assets/thanatos_intel/js/thanatos_intro.js`:

```python
web_include_js=[
    '/assets/thanatos_intel/js/fx_widget.js',
    '/assets/thanatos_intel/js/thanatos_login.js',
    '/assets/thanatos_intel/js/thanatos_intro.js',  # ← new
]
```

### 3. Rebuild & deploy

```bash
bench build --app thanatos_intel
bench --site <site-name> clear-cache
```

That's the whole integration.

## How it works

- **Gate**: on every page, the script checks `body.thanatos-home` (set by `www/index.py`'s `context.body_class = 'thanatos-home'`). It only injects the overlay on the home.
- **First-visit**: checks `localStorage.thanatos_intro_seen`. If `'1'`, just shows the **"▶ Replay intro"** button bottom-right and exits.
- **Audio gate**: browsers block AudioContext until a user gesture. The intro shows a centered **"♪ ENTER WITH SOUND · Click to begin · ESC to skip"** overlay. Click anywhere → audio resumes and the animation starts.
- **Animation**: a 1920×1080 logical stage scaled to fit the viewport. Camera-push scale (1.0 → 1.12), particles streaming radially, golden rings tracing + rotating, scan-line sweep, monumental THANATOS wordmark assembling letter-by-letter, tagline reveal.
- **Audio**: 12.5-second synchronized synthesized audio (drone, shimmer, whoosh, chime, 8 metallic ticks per letter, bass impact, high sweep, transition whoosh, settle chord). No external audio files — all Web Audio API.
- **Dissolve**: at t=10.5s the central logo morphs to the position/size of the live hero logo (`.t-hero-logo img`, computed from `getBoundingClientRect` at runtime). Overlay fades and removes itself.
- **After intro**: a small **"▶ Replay intro"** button persists bottom-right. Clicking it clears the localStorage flag and re-runs.
- **Skip**: ESC, or click "› Skip intro" bottom-left of the overlay.
- **Force replay (dev)**: append `?intro=1` to the URL.
- **Reduced motion**: if user has `prefers-reduced-motion: reduce`, intro is skipped entirely.

## Brand alignment

The vanilla port uses the brand tokens already defined in `thanatos_intel/public/css/thanatos_web.css`:

- `--gold: #C8A96E` — primary
- `--gold2: #E0C58A` — highlight
- Logo asset: `/assets/thanatos_intel/images/thanatos-logo-mark.png` (already in repo)
- Font: **Cinzel Decorative** + **Cinzel** (already loaded on the home via `index.html`)
- Wordmark gradient mirrors the hero brand styling

If you change brand tokens, update the constants at the top of `thanatos_intro.js`:
```js
const GOLD = '#C8A96E';
const GOLD_BRIGHT = '#E0C58A';
const GOLD_RGB = '200,169,110';
```

## Cue timing (audio + visual sync)

| t (s) | Visual | Audio |
|---|---|---|
| 0.0 | Void | Drone start (sub 55Hz + bass 110Hz) |
| 1.6 | Outer ring traces | Shimmer (4 partials 1200–3600Hz) |
| 2.4 | Scan-line sweep | Whoosh (band-pass 200→4000Hz) |
| 3.5 | Logo materializes | Bell chime (880+1320+1760Hz) |
| 4.8–5.7 | THANATOS letters assemble | 8× metallic tick (pitch rises) |
| 6.1 | Wordmark complete | Bass impact (120→45Hz drop) |
| 7.4 | Tagline reveal | High sweep (1500→5500Hz) |
| 10.5 | Logo morph to hero | Transition whoosh + drone stop |
| 12.0 | Overlay fades | Settle chord A2–E3–A3 |

To re-tune timings or visuals, edit the corresponding `smoothstep(start, end, time)` calls inside each `build*` function. The CUES array at the top maps audio events to time thresholds.

## Performance notes

- ~110 streaming particles + SVG rings + monumental text = ~150 absolutely-positioned DOM nodes.
- Tested fine on modern desktop and recent mobile.
- On older mobiles, consider lowering particle count: change `for (let i = 0; i < 110; i++)` in `buildParticleField()` to `60`.
- The intro is **deferred to DOMContentLoaded** so it doesn't block initial render of the home content underneath.

## Testing

```bash
# In your local dev site
# 1. Visit home → intro plays
# 2. Refresh → no intro (localStorage gate); see "▶ Replay intro" bottom-right
# 3. Click Replay → intro plays again
# 4. Force replay via URL:
#    https://thanatos.agency/?intro=1
# 5. Skip with ESC
# 6. Reset state via browser console:
#    localStorage.removeItem('thanatos_intro_seen')
```

## Rollback

If you need to disable the intro temporarily:

1. Remove the line from `web_include_js` in `hooks.py`, OR
2. Set in browser/CDN: `localStorage.setItem('thanatos_intro_seen', '1')` for every visitor (not practical), OR
3. Add a feature flag at the top of `thanatos_intro.js`:
   ```js
   const ENABLED = true; // set to false to disable
   if (!ENABLED) return;
   ```

## Files in this folder

- `thanatos_intro.js` — the vanilla JS port to deploy
- `INTEGRATION.md` — this file

## Files in the parent `design_handoff_thanatos_intro/`

- `README.md` — design specification (timings, colors, audio cues, geometry)
- `intro.jsx` — the original React reference implementation
- `Thanatos Intro.html` — standalone preview (open in browser)
- `logo.png` — logo asset (same as `thanatos-logo-mark.png`)
- `CLAUDE_CODE_PROMPT.md` — prompt to paste into Claude Code
